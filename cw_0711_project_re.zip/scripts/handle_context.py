#!/usr/bin/env python
# coding=UTF-8
"""
@Author: STAURL.COM
@Contact: admin@staurl.com
@Project: future_loan_interface_test
@File: handle_context.py
@Time: 2019/7/17 0:36
@Desc: S
"""
