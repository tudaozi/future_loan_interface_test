#!/usr/bin/env python
# coding=UTF-8
"""
@Author: STAURL.COM
@Contact: admin@staurl.com
@Project: future_loan_interface_test
@File: __init__.py.py
@Time: 2019-07-28 23:42
@Desc: S
"""
